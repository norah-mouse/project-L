/** @format */

$(document).ready(function () {
  $("#submit_btn").click(function () {
    var Username = $("#Username").val()
    var Password = $("#Password").val()
    if (Username === "" || Password === "") {
      alert("Username or Password cannot be empty")
    }
    console.log("Username: ", Username)
    console.log("Password: ", Password)
  })
})
